PA6

BigInteger.cpp:file containing the functions for the BigInteger ADT.

BigInteger.h:Header file for the BigInteger ADT that contains its prototypes.

BigIntegerTest.cpp:Testing file for the BigInteger ADT.

List.cpp:file that contains the functions for the List ADT.

List.h:Header file for the List ADT that contains its prototypes.

ListTest.cpp:Testing file for the List ADT.

Arithmetic.cpp:Client file for the BigInteger ADT.

Makefile: creates object and executable files for all the c++ files in PA6.
